function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}


function openNav2() {
    document.getElementById("mySidenav2").style.width = "100%";
}

function closeNav2() {
    document.getElementById("mySidenav2").style.width = "0";
}